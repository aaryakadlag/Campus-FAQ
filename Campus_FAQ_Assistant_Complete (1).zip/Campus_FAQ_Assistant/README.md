# Campus FAQ Assistant

## 1. Introduction
Campus FAQ Assistant is a beginner-friendly Python chatbot that answers common student questions about college information.

## 2. Objective
To make basic campus information easier to access by allowing students to type questions and receive predefined answers.

## 3. Features
- Answers questions about college timings, admissions, library, exams, courses, fees, holidays, contacts and scholarships.
- Accepts different ways of asking using keyword matching.
- Includes a help command.
- Handles blank and unrecognized questions.
- Runs in the VS Code terminal.

## 4. Technologies
- Python 3
- Dictionaries
- Functions
- Loops
- Conditional statements
- String handling

No third-party packages are required.

## 5. How to run in VS Code
1. Install Python 3 and Visual Studio Code.
2. Open VS Code.
3. Select File > Open Folder and open this project folder.
4. Open `main.py`.
5. Open Terminal > New Terminal.
6. Run `python main.py` (on some Windows installations use `py main.py`).
7. Type a question. Type `help` for topics and `exit` to close.

## 6. Sample questions
- What are the college timings?
- How can I get admission?
- Is the library open?
- When are the exams?
- Which courses are available?
- What are the fees?
- Are there any holidays?
- How do I contact the college?
- Is there a scholarship?

## 7. Important customization
The answers in this project are sample/demo answers. Before submission, replace them in `main.py` with correct details confirmed by your own college. Do not submit sample timings or fee information as official college information.

## 8. GitHub upload procedure
1. Sign in at https://github.com/.
2. Click the plus (+) icon and choose New repository.
3. Enter repository name `Campus-FAQ-Assistant`.
4. Add a short description, such as `A Python chatbot that answers common campus questions`.
5. Choose Public or Private according to your teacher's instructions.
6. Click Create repository.
7. In the new repository, choose Add file > Upload files.
8. Upload `main.py`, `README.md`, `PROJECT_REPORT.pdf` and `FLOWCHART.png` from this folder.
9. Enter commit message `Add Campus FAQ Assistant mini project`.
10. Click Commit changes.
11. Open the repository page and check that all files are visible.
12. Copy the repository URL and submit it as instructed by your teacher.

## 9. Testing
Try at least these inputs:
| Input | Expected behaviour |
|---|---|
| What are college timings? | Displays the sample timings |
| Tell me about admission | Displays admission office guidance |
| Is the library open? | Displays library timings |
| What is the weather? | Displays the not-found response |
| (blank input) | Asks the user to type a question |
| help | Displays available topics |
| exit | Closes the assistant |

## 10. Limitations
- It uses keyword matching, not a trained AI language model.
- It can misunderstand questions that do not contain known keywords.
- The answers must be updated manually.

## 11. Future scope
- Add a graphical user interface.
- Store FAQs in a database.
- Add an admin page to update answers.
- Build a web version.
- Use natural-language processing to understand more question variations.
