"""
Campus FAQ Assistant
A beginner-friendly Python mini-project.
Replace the sample answers with verified information from your college.
"""

faqs = {
    "timing": "College working hours are 9:00 AM to 4:00 PM, Monday to Friday.",
    "admission": "For admission details, contact the college admission office.",
    "library": "The library is open from 9:00 AM to 5:00 PM on working days.",
    "exam": "Examination timetables are announced by the examination department.",
    "course": "Contact the academic office for the current list of courses.",
    "fees": "For the fee structure and payment details, contact the accounts office.",
    "holiday": "College holidays are announced through official college notices.",
    "contact": "Contact the college reception for department contact details.",
    "principal": "Contact the college office to request an appointment with the principal.",
    "scholarship": "For scholarship information, contact the student section."
}

def find_answer(question):
    """Find an FAQ answer using keywords in the student's question."""
    question = question.lower().strip()

    keyword_groups = {
        "timing": ["timing", "time", "working hours", "college hours"],
        "admission": ["admission", "enroll", "enrollment", "apply"],
        "library": ["library", "books", "book"],
        "exam": ["exam", "examination", "timetable", "test"],
        "course": ["course", "courses", "program", "programme"],
        "fees": ["fee", "fees", "payment"],
        "holiday": ["holiday", "holidays", "vacation"],
        "contact": ["contact", "phone", "email", "reception"],
        "principal": ["principal", "appointment"],
        "scholarship": ["scholarship", "financial aid"]
    }

    for faq_key, keywords in keyword_groups.items():
        if any(keyword in question for keyword in keywords):
            return faqs[faq_key]

    return ("Sorry, I could not find an answer to that question. "
            "Please contact your college office.")

def show_welcome():
    print("=" * 55)
    print("              CAMPUS FAQ ASSISTANT")
    print("=" * 55)
    print("Welcome! I can help with common college questions.")
    print("Topics: timings, admission, library, exams, courses,")
    print("fees, holidays, contact details and scholarships.")
    print("Type 'help' to see topics or 'exit' to close.")

def main():
    show_welcome()

    while True:
        question = input("\nYou: ").strip()

        if question.lower() in ("exit", "quit", "bye"):
            print("Assistant: Thank you for using Campus FAQ Assistant!")
            print("Goodbye!")
            break

        if question.lower() == "help":
            print("Assistant: You can ask about college timings, admission,")
            print("library, exams, courses, fees, holidays, contact or scholarships.")
            continue

        if not question:
            print("Assistant: Please type a question.")
            continue

        print("Assistant:", find_answer(question))

if __name__ == "__main__":
    main()
